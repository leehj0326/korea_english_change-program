# 한영 변환기 — 최종 소스 프로젝트

PyCharm에서 이 폴더를 프로젝트로 연 뒤 hangul_switcher.pyw를 실행하세요.
실행에 필요한 외부 pip 패키지는 없습니다. Python과 Tkinter/Tcl/Tk가 필요합니다.

이 PC의 기존 시스템 인터프리터:
C:\Users\turing03\AppData\Local\Python\pythoncore-3.14-64\python.exe

실행 파일을 빌드할 때만 다음 명령을 사용합니다.

```powershell
python -m pip install -r requirements-dev.txt
powershell -File .\build.ps1 -Python python
```

빌드 결과는 dist, 임시 빌드 파일은 .build에 생성됩니다.
상세 사용법은 README_hangul_switcher.txt를 참고하세요.
이 폴더는 기존 PythonProject4와 별개인 최종 프로젝트입니다.
트레이 팝업은 기존 UI를 사용하며, 코드 최적화와 트레이 오류 수정은 유지합니다.
