# -*- coding: utf-8 -*-
"""
선택한 글을 한/영 자판 기준으로 바꾸는 Windows 트레이 앱입니다.

기본 단축키는 CapsLock입니다. CapsLock 기본 설정에서만 저수준 키보드
훅을 사용해 CapsLock의 원래 토글 동작을 막습니다. 다른 단축키는 Windows
RegisterHotKey를 사용합니다.

변환은 선택 영역을 Ctrl+C로 복사하고, 변환 결과를 Ctrl+V로 붙여넣습니다.
따라서 Ctrl+Z로 되돌릴 수 있는지는 대상 앱의 편집/붙여넣기 구현에 따라
달라집니다. 일반적인 텍스트 편집기에서는 대개 한 번의 실행 취소로
변환 전 텍스트를 복구할 수 있습니다.
"""

from __future__ import annotations

import ctypes
import json
import os
import queue
import re
import sys
import time
from functools import lru_cache
from io import StringIO
import threading
import tkinter as tk
from ctypes import wintypes
from pathlib import Path
from tkinter import messagebox


if os.name != "nt":
    raise SystemExit("이 프로그램은 Windows에서 실행해야 합니다.")

APP_NAME = "넌 한영키를 누르지 못했다"


# ---------------------------------------------------------------------------
# 한글/영문 자판 변환
# ---------------------------------------------------------------------------

ENG_TO_KOR = {
    "r": "ㄱ", "s": "ㄴ", "e": "ㄷ", "f": "ㄹ", "a": "ㅁ",
    "q": "ㅂ", "t": "ㅅ", "d": "ㅇ", "w": "ㅈ", "c": "ㅊ",
    "z": "ㅋ", "x": "ㅌ", "v": "ㅍ", "g": "ㅎ",
    "k": "ㅏ", "o": "ㅐ", "i": "ㅑ", "j": "ㅓ", "p": "ㅔ",
    "u": "ㅕ", "h": "ㅗ", "y": "ㅛ", "n": "ㅜ", "b": "ㅠ",
    "m": "ㅡ", "l": "ㅣ",
}
SHIFTED_ENG_TO_KOR = {
    "R": "ㄲ", "E": "ㄸ", "Q": "ㅃ", "T": "ㅆ", "W": "ㅉ",
    "O": "ㅒ", "P": "ㅖ",
}

CHO = (
    "ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ",
    "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ",
)
JUNG = (
    "ㅏ", "ㅐ", "ㅑ", "ㅒ", "ㅓ", "ㅔ", "ㅕ", "ㅖ", "ㅗ",
    "ㅘ", "ㅙ", "ㅚ", "ㅛ", "ㅜ", "ㅝ", "ㅞ", "ㅟ", "ㅠ",
    "ㅡ", "ㅢ", "ㅣ",
)
JONG = (
    "", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ",
    "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ",
    "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ",
)
COMPLEX_VOWELS = {
    "ㅗㅏ": "ㅘ", "ㅗㅐ": "ㅙ", "ㅗㅣ": "ㅚ",
    "ㅜㅓ": "ㅝ", "ㅜㅔ": "ㅞ", "ㅜㅣ": "ㅟ", "ㅡㅣ": "ㅢ",
}
COMPLEX_FINALS = {
    "ㄱㅅ": "ㄳ", "ㄴㅈ": "ㄵ", "ㄴㅎ": "ㄶ", "ㄹㄱ": "ㄺ",
    "ㄹㅁ": "ㄻ", "ㄹㅂ": "ㄼ", "ㄹㅅ": "ㄽ", "ㄹㅌ": "ㄾ",
    "ㄹㅍ": "ㄿ", "ㄹㅎ": "ㅀ", "ㅂㅅ": "ㅄ",
}
CHO_INDEX = {value: index for index, value in enumerate(CHO)}
JUNG_INDEX = {value: index for index, value in enumerate(JUNG)}
JONG_INDEX = {value: index for index, value in enumerate(JONG)}
VOWELS = set(JUNG)
FINAL_CONSONANTS = set(JONG[1:])

KOR_TO_ENG = {value: key for key, value in {**ENG_TO_KOR, **SHIFTED_ENG_TO_KOR}.items()}
KOR_TO_ENG.update({
    combined: "".join(KOR_TO_ENG[ch] for ch in pair)
    for pair, combined in (COMPLEX_VOWELS | COMPLEX_FINALS).items()
})


def _compose_latin_run(run: str) -> str:
    jamos = run.translate(LATIN_TO_JAMO)

    out = StringIO()
    i = 0
    while i < len(jamos):
        initial = jamos[i]
        if (
            initial in CHO_INDEX
            and i + 1 < len(jamos)
            and jamos[i + 1] in VOWELS
        ):
            i += 1
            vowel = jamos[i]
            i += 1

            if i < len(jamos):
                combined = COMPLEX_VOWELS.get(vowel + jamos[i])
                if combined:
                    vowel = combined
                    i += 1

            final = ""
            if (i < len(jamos) and jamos[i] in FINAL_CONSONANTS
                    and not (i + 1 < len(jamos) and jamos[i + 1] in VOWELS)):
                final = jamos[i]
                i += 1
                if i < len(jamos):
                    cluster = COMPLEX_FINALS.get(final + jamos[i])
                    if cluster and not (i + 1 < len(jamos) and jamos[i + 1] in VOWELS):
                        final = cluster
                        i += 1

            syllable_index = (
                (CHO_INDEX[initial] * 21 + JUNG_INDEX[vowel]) * 28
                + JONG_INDEX[final]
            )
            out.write(chr(0xAC00 + syllable_index))
        else:
            out.write(initial)
            i += 1

    return out.getvalue()


@lru_cache(maxsize=256)
def _korean_char_to_keys(ch: str) -> str:
    if "가" <= ch <= "힣":
        initial, tail = divmod(ord(ch) - 0xAC00, 588)
        vowel, final = divmod(tail, 28)
        return (KOR_TO_ENG[CHO[initial]] + KOR_TO_ENG[JUNG[vowel]]
                + KOR_TO_ENG.get(JONG[final], ""))
    return KOR_TO_ENG.get(ch, ch)


def _convert_korean_run(run: str) -> str:
    out = StringIO()
    out.writelines(map(_korean_char_to_keys, run))
    return out.getvalue()


LATIN_TO_JAMO = str.maketrans({
    **ENG_TO_KOR,
    **{key.upper(): value for key, value in ENG_TO_KOR.items()},
    **SHIFTED_ENG_TO_KOR,
})
TEXT_RUNS = re.compile(r"[A-Za-z]+|[\uAC00-\uD7A3\u3130-\u318F\u1100-\u11FF]+")


def _convert_match(match) -> str:
    run = match.group()
    return _compose_latin_run(run) if run[0].isascii() else _convert_korean_run(run)


def convert_text(text: str) -> str:
    """영문 자판 문자열과 한글을 기존 자판 규칙 그대로 상호 변환합니다."""
    return TEXT_RUNS.sub(_convert_match, text)


# ---------------------------------------------------------------------------
# 단축키 설정
# ---------------------------------------------------------------------------

MODIFIERS = {
    "ctrl": 0x0002,
    "control": 0x0002,
    "alt": 0x0001,
    "shift": 0x0004,
    "win": 0x0008,
    "windows": 0x0008,
}
MODIFIER_NAMES = {
    "ctrl": "Ctrl",
    "control": "Ctrl",
    "alt": "Alt",
    "shift": "Shift",
    "win": "Win",
    "windows": "Win",
}
KEY_LABELS = {
    0x20: "Space", 0x09: "Tab", 0x0D: "Enter", 0x1B: "Esc",
    0x08: "Backspace", 0x2E: "Delete", 0x2D: "Insert",
    0x24: "Home", 0x23: "End", 0x21: "PageUp", 0x22: "PageDown",
    0x26: "Up", 0x28: "Down", 0x25: "Left", 0x27: "Right",
    0x14: "CapsLock", 0xBC: "Comma", 0xBE: "Period",
    0xBD: "Minus", 0xBB: "Plus",
}
KEY_NAMES = {label.casefold(): vk for vk, label in KEY_LABELS.items()}
KEY_NAMES.update({"return": 0x0D, "escape": 0x1B, "caps": 0x14})
CAPTURE_MODIFIER_KEYS = {
    0x10: "Shift", 0xA0: "Shift", 0xA1: "Shift",
    0x11: "Ctrl", 0xA2: "Ctrl", 0xA3: "Ctrl",
    0x12: "Alt", 0xA4: "Alt", 0xA5: "Alt",
    0x5B: "Win", 0x5C: "Win",
}


def _capture_modifier_name(keycode: int) -> str | None:
    return CAPTURE_MODIFIER_KEYS.get(keycode)


class Shortcut:
    def __init__(self, text: str, modifiers: int, vk: int, caps_lock: bool):
        self.text = text
        self.modifiers = modifiers
        self.vk = vk
        self.caps_lock = caps_lock


def parse_shortcut(raw: str) -> Shortcut:
    pieces = [part.strip() for part in raw.split("+")]
    if not raw.strip() or any(not part for part in pieces):
        raise ValueError("단축키를 입력해 주세요. 예: CapsLock 또는 Ctrl+Space")
    if len(pieces) > 2:
        raise ValueError("단축키는 최대 두 키 조합까지 설정할 수 있습니다.")

    modifier_bits = 0
    modifier_labels = []
    key_piece = None
    for piece in pieces:
        low = piece.casefold()
        if low in MODIFIERS:
            bit = MODIFIERS[low]
            if modifier_bits & bit:
                raise ValueError("같은 조합 키를 두 번 입력했습니다.")
            modifier_bits |= bit
            modifier_labels.append(MODIFIER_NAMES[low])
        elif key_piece is None:
            key_piece = piece
        else:
            raise ValueError("조합은 수정 키 하나와 일반 키 하나로 입력해 주세요.")

    if key_piece is None:
        raise ValueError("Ctrl, Alt, Shift, Win만으로는 단축키를 만들 수 없습니다.")

    low_key = key_piece.casefold()
    if low_key in KEY_NAMES:
        vk = KEY_NAMES[low_key]
        key_label = KEY_LABELS.get(vk, "CapsLock")
    elif len(key_piece) == 1 and key_piece.isascii() and key_piece.isalpha():
        vk = ord(key_piece.upper())
        key_label = key_piece.upper()
    elif len(key_piece) == 1 and key_piece.isascii() and key_piece.isdigit():
        vk = ord(key_piece)
        key_label = key_piece
    elif low_key.startswith("f") and low_key[1:].isdigit():
        number = int(low_key[1:])
        if not 1 <= number <= 24:
            raise ValueError("F1부터 F24까지 사용할 수 있습니다.")
        vk = 0x70 + number - 1
        key_label = f"F{number}"
    else:
        raise ValueError("키는 문자, 숫자, F1~F24 또는 Space/Enter 등으로 입력해 주세요.")

    caps_lock = vk == 0x14 and modifier_bits == 0
    if vk == 0x14 and modifier_bits:
        raise ValueError("CapsLock은 현재 단독 단축키로만 설정할 수 있습니다.")

    label = "+".join(modifier_labels + [key_label])
    return Shortcut(label, modifier_bits, vk, caps_lock)


# ---------------------------------------------------------------------------
# Windows API: 전역 단축키, 키 입력, 시스템 트레이, 클립보드
# ---------------------------------------------------------------------------

LRESULT = ctypes.c_ssize_t
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, WPARAM, LPARAM)
HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, WPARAM, LPARAM)

WM_DESTROY = 0x0002
WM_CLOSE = 0x0010
WM_HOTKEY = 0x0312
WM_APP = 0x8000
WM_TRAY = WM_APP + 1
WM_SET_SHORTCUT = WM_APP + 2
WM_SET_CAPTURE_MODE = WM_APP + 3
WM_SET_ENABLED = WM_APP + 4
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WH_KEYBOARD_LL = 13
VK_CAPITAL = 0x14
VK_CONTROL = 0x11
KEYEVENTF_KEYUP = 0x0002
MOD_NOREPEAT = 0x4000
HOTKEY_ID = 1
IMAGE_ICON = 1
LR_LOADFROMFILE = 0x0010
LR_DEFAULTSIZE = 0x0040
NIM_ADD = 0x00000000
NIM_MODIFY = 0x00000001
NIM_DELETE = 0x00000002
NIF_MESSAGE = 0x00000001
NIF_ICON = 0x00000002
NIF_TIP = 0x00000004
CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002


class NotifyIconVersionUnion(ctypes.Union):
    _fields_ = [
        ("uTimeout", wintypes.UINT),
        ("uVersion", wintypes.UINT),
    ]


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uID", wintypes.UINT),
        ("uFlags", wintypes.UINT),
        ("uCallbackMessage", wintypes.UINT),
        ("hIcon", wintypes.HICON),
        ("szTip", wintypes.WCHAR * 128),
        ("dwState", wintypes.DWORD),
        ("dwStateMask", wintypes.DWORD),
        ("szInfo", wintypes.WCHAR * 256),
        ("timeout_or_version", NotifyIconVersionUnion),
        ("szInfoTitle", wintypes.WCHAR * 64),
        ("dwInfoFlags", wintypes.DWORD),
        ("guidItem", ctypes.c_byte * 16),
        ("hBalloonIcon", wintypes.HICON),
    ]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [
        ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
    ]


user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)

user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, WPARAM, LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
user32.RegisterClassW.restype = wintypes.ATOM
user32.RegisterWindowMessageW.argtypes = [wintypes.LPCWSTR]
user32.RegisterWindowMessageW.restype = wintypes.UINT
user32.UnregisterClassW.argtypes = [wintypes.LPCWSTR, wintypes.HINSTANCE]
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID,
]
user32.CreateWindowExW.restype = wintypes.HWND
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, WPARAM, LPARAM]
user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.GetMessageW.restype = ctypes.c_int
user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
user32.RegisterHotKey.restype = wintypes.BOOL
user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
user32.SetWindowsHookExW.restype = ctypes.c_void_p
user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, WPARAM, LPARAM]
user32.CallNextHookEx.restype = LRESULT
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = wintypes.SHORT
user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
user32.LoadIconW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR]
user32.LoadIconW.restype = wintypes.HICON
user32.LoadImageW.argtypes = [
    wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
    ctypes.c_int, ctypes.c_int, wintypes.UINT,
]
user32.LoadImageW.restype = wintypes.HANDLE
user32.DestroyIcon.argtypes = [wintypes.HICON]
user32.DestroyIcon.restype = wintypes.BOOL
user32.OpenClipboard.argtypes = [wintypes.HWND]
user32.OpenClipboard.restype = wintypes.BOOL
user32.CloseClipboard.restype = wintypes.BOOL
user32.EmptyClipboard.restype = wintypes.BOOL
user32.GetClipboardData.argtypes = [wintypes.UINT]
user32.GetClipboardData.restype = wintypes.HANDLE
user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
user32.SetClipboardData.restype = wintypes.HANDLE
user32.GetClipboardSequenceNumber.restype = wintypes.DWORD
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
kernel32.GlobalLock.restype = wintypes.LPVOID
kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]
shell32.Shell_NotifyIconW.argtypes = [wintypes.DWORD, ctypes.POINTER(NOTIFYICONDATAW)]
shell32.Shell_NotifyIconW.restype = wintypes.BOOL


def _win_error() -> str:
    code = ctypes.get_last_error()
    if code:
        return ctypes.FormatError(code).strip()
    return "Windows에서 작업을 완료하지 못했습니다."


def _modifiers_down() -> bool:
    return any(user32.GetAsyncKeyState(key) & 0x8000 for key in (0x10, 0x11, 0x12, 0x5B, 0x5C))


def _set_window_icon(window, icon_path, *, default=False) -> None:
    try:
        if default:
            window.iconbitmap(default=str(icon_path))
        else:
            window.iconbitmap(str(icon_path))
    except tk.TclError:
        pass


def _press_ctrl_key(vk: int) -> None:
    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)


def _read_clipboard_text(owner_hwnd) -> str | None:
    if not user32.OpenClipboard(owner_hwnd):
        return None
    try:
        handle = user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return None
        pointer = kernel32.GlobalLock(handle)
        if not pointer:
            return None
        try:
            return ctypes.wstring_at(pointer)
        finally:
            kernel32.GlobalUnlock(handle)
    finally:
        user32.CloseClipboard()


def _write_clipboard_text(owner_hwnd, text: str) -> bool:
    if not user32.OpenClipboard(owner_hwnd):
        return False
    memory = None
    try:
        if not user32.EmptyClipboard():
            return False
        data = (text + "\0").encode("utf-16-le")
        memory = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not memory:
            return False
        pointer = kernel32.GlobalLock(memory)
        if not pointer:
            kernel32.GlobalFree(memory)
            memory = None
            return False
        try:
            ctypes.memmove(pointer, data, len(data))
        finally:
            kernel32.GlobalUnlock(memory)
        if not user32.SetClipboardData(CF_UNICODETEXT, memory):
            kernel32.GlobalFree(memory)
            memory = None
            return False
        memory = None  # 성공하면 메모리 소유권은 Windows 클립보드로 넘어갑니다.
        return True
    finally:
        if memory:
            kernel32.GlobalFree(memory)
        user32.CloseClipboard()


class NativeHost:
    """전역 단축키와 트레이 메시지를 받는 숨김 Windows 창."""

    def __init__(self, events: queue.Queue, initial_shortcut: Shortcut, *, diagnostics=False):
        self.events = events
        self.diagnostics = diagnostics
        self.initial_shortcut = initial_shortcut
        self.hwnd = None
        self.thread = None
        self.ready = threading.Event()
        self.startup_error = None
        self.window_class_name = f"HangulSwitcher_{os.getpid()}_{id(self)}"
        self.instance = None
        self.taskbar_created_message = 0
        # WINFUNCTYPE creates runtime callback types that PyCharm's ctypes stubs
        # currently describe as a class instead of a callback instance.
        # noinspection PyTypeChecker
        self._wndproc_callback = WNDPROC(self._window_proc)
        # noinspection PyTypeChecker
        self._hook_callback = HOOKPROC(self._keyboard_proc)
        self._hook = None
        self._caps_is_down = False
        self._capture_mode = False
        self._enabled = True
        self._configured_shortcut = initial_shortcut
        self._active_shortcut = None
        self._pending_shortcut = None
        self._pending_lock = threading.Lock()
        self._tray_icon_added = False
        self._notify_data = None
        self._icon_handle = None
        self._owns_icon = False

    def start(self) -> None:
        self.thread = threading.Thread(
            target=self._message_thread, name="HangulSwitcherWin32", daemon=True
        )
        self.thread.start()
        if not self.ready.wait(5):
            raise RuntimeError("Windows 메시지 창을 시작하지 못했습니다.")
        if self.startup_error:
            raise RuntimeError(self.startup_error)

    def set_shortcut(self, shortcut: Shortcut) -> None:
        with self._pending_lock:
            self._pending_shortcut = shortcut
        if not user32.PostMessageW(self.hwnd, WM_SET_SHORTCUT, 0, 0):
            self.events.put(("shortcut_result", False, shortcut, _win_error()))

    def set_capture_mode(self, enabled: bool) -> None:
        user32.PostMessageW(self.hwnd, WM_SET_CAPTURE_MODE, int(enabled), 0)

    def set_enabled(self, enabled: bool) -> None:
        if not user32.PostMessageW(self.hwnd, WM_SET_ENABLED, int(enabled), 0):
            self.events.put(("enabled_result", enabled, False, _win_error()))

    def stop(self) -> None:
        if self.hwnd:
            user32.PostMessageW(self.hwnd, WM_CLOSE, 0, 0)
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2)

    def _message_thread(self) -> None:
        try:
            self.instance = kernel32.GetModuleHandleW(None)
            self.taskbar_created_message = user32.RegisterWindowMessageW("TaskbarCreated")
            if not self.taskbar_created_message:
                raise RuntimeError(_win_error())
            wndclass = WNDCLASSW()
            wndclass.lpfnWndProc = self._wndproc_callback
            wndclass.hInstance = self.instance
            wndclass.lpszClassName = self.window_class_name
            if not user32.RegisterClassW(ctypes.byref(wndclass)):
                raise RuntimeError(_win_error())

            self.hwnd = user32.CreateWindowExW(
                0, self.window_class_name, APP_NAME, 0,
                0, 0, 0, 0, None, None, self.instance, None,
            )
            if not self.hwnd:
                raise RuntimeError(_win_error())

            self._add_tray_icon()
            self._apply_shortcut(self.initial_shortcut, announce=True)
            self.ready.set()

            message = wintypes.MSG()
            while True:
                result = user32.GetMessageW(ctypes.byref(message), None, 0, 0)
                if result <= 0:
                    break
                user32.TranslateMessage(ctypes.byref(message))
                user32.DispatchMessageW(ctypes.byref(message))
        except Exception as exc:
            self.startup_error = str(exc)
            self.ready.set()
            self.events.put(("startup_error", str(exc)))
        finally:
            if self.hwnd:
                self._remove_shortcut()
                self._remove_tray_icon()
                user32.UnregisterClassW(self.window_class_name, self.instance)

    def _add_tray_icon(self) -> None:
        if self.diagnostics:
            return
        if not self._icon_handle:
            icon_path = Path(__file__).with_name("hangul_switcher.ico")
            self._icon_handle = user32.LoadImageW(
                None, str(icon_path), IMAGE_ICON, 0, 0,
                LR_LOADFROMFILE | LR_DEFAULTSIZE,
            )
            self._owns_icon = bool(self._icon_handle)
            if not self._icon_handle:
                # 아이콘 파일을 읽을 수 없으면 Windows 기본 아이콘으로 실행을 이어갑니다.
                self._icon_handle = user32.LoadIconW(
                    None, ctypes.cast(ctypes.c_void_p(32512), wintypes.LPCWSTR)
                )
        data = NOTIFYICONDATAW()
        data.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        data.hWnd = self.hwnd
        data.uID = 1
        data.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        data.uCallbackMessage = WM_TRAY
        data.hIcon = self._icon_handle
        data.szTip = self._tray_tip()
        if shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(data)):
            self._notify_data = data
            self._tray_icon_added = True
            self.events.put(("tray_ready",))
        else:
            self.events.put(("tray_error", _win_error()))

    def _remove_tray_icon(self) -> None:
        if self._tray_icon_added and self._notify_data:
            shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._notify_data))
            self._tray_icon_added = False
        if self._icon_handle and self._owns_icon:
            # LoadImageW로 읽은 아이콘은 앱이 직접 해제해야 합니다.
            user32.DestroyIcon(self._icon_handle)
        if self._icon_handle:
            self._icon_handle = None
            self._owns_icon = False

    def _register_one(self, shortcut: Shortcut) -> tuple[bool, str | None]:
        if self.diagnostics:
            return True, None
        if shortcut.caps_lock:
            self._caps_is_down = False
            self._hook = user32.SetWindowsHookExW(
                WH_KEYBOARD_LL, self._hook_callback, self.instance, 0
            )
            if not self._hook:
                return False, _win_error()
        else:
            modifiers = shortcut.modifiers | MOD_NOREPEAT
            if not user32.RegisterHotKey(self.hwnd, HOTKEY_ID, modifiers, shortcut.vk):
                return False, _win_error()
        self._active_shortcut = shortcut
        return True, None

    def _remove_shortcut(self) -> None:
        if self._active_shortcut:
            if self._active_shortcut.caps_lock:
                if self._hook:
                    user32.UnhookWindowsHookEx(self._hook)
                    self._hook = None
            else:
                user32.UnregisterHotKey(self.hwnd, HOTKEY_ID)
        self._active_shortcut = None

    def _tray_tip(self) -> str:
        return APP_NAME if self._enabled else f"{APP_NAME} (일시 중단됨)"

    def _update_tray_tip(self) -> None:
        if not self._tray_icon_added or not self.hwnd:
            return
        data = NOTIFYICONDATAW()
        data.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        data.hWnd = self.hwnd
        data.uID = 1
        data.uFlags = NIF_TIP
        data.szTip = self._tray_tip()
        shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(data))

    def _apply_enabled(self, enabled: bool) -> None:
        if enabled == self._enabled:
            self.events.put(("enabled_result", enabled, True, None))
            return

        if not enabled:
            self._remove_shortcut()
            self._enabled = False
            self._update_tray_tip()
            self.events.put(("enabled_result", False, True, None))
            return

        success, error = self._register_one(self._configured_shortcut)
        if success:
            self._enabled = True
            self._update_tray_tip()
            self.events.put(("enabled_result", True, True, None))
        else:
            self.events.put(("enabled_result", False, False, error))

    def _apply_shortcut(self, shortcut: Shortcut, announce: bool) -> None:
        if not self._enabled:
            self._configured_shortcut = shortcut
            if announce:
                self.events.put(("shortcut_result", True, shortcut, None))
            return

        previous = self._active_shortcut
        self._remove_shortcut()
        success, error = self._register_one(shortcut)
        if not success:
            self._active_shortcut = None
            if previous:
                restored, _ = self._register_one(previous)
                if not restored:
                    self._active_shortcut = None
            if announce:
                self.events.put(("shortcut_result", False, shortcut, error))
            return
        self._configured_shortcut = shortcut
        if announce:
            self.events.put(("shortcut_result", True, shortcut, None))

    def _window_proc(self, hwnd, message, wparam, lparam):
        if message == self.taskbar_created_message:
            # Explorer가 다시 시작되면 이전 알림 영역 아이콘은 사라지므로 다시 등록합니다.
            self._tray_icon_added = False
            self._add_tray_icon()
            return 0
        if message == WM_HOTKEY:
            self.events.put(("hotkey",))
            return 0
        if message == WM_SET_SHORTCUT:
            with self._pending_lock:
                shortcut = self._pending_shortcut
                self._pending_shortcut = None
            if shortcut:
                self._apply_shortcut(shortcut, announce=True)
            return 0
        if message == WM_SET_CAPTURE_MODE:
            self._capture_mode = bool(wparam)
            return 0
        if message == WM_SET_ENABLED:
            self._apply_enabled(bool(wparam))
            return 0
        if message == WM_TRAY:
            event = int(lparam) & 0xFFFF
            if event in (0x0202, 0x0203):  # 왼쪽 클릭/더블 클릭
                self.events.put(("tray_left",))
            elif event == 0x0205:  # 오른쪽 클릭
                self.events.put(("tray_right",))
            return 0
        if message == WM_CLOSE:
            user32.DestroyWindow(hwnd)
            return 0
        if message == WM_DESTROY:
            self._remove_shortcut()
            self._remove_tray_icon()
            user32.PostQuitMessage(0)
            return 0
        return user32.DefWindowProcW(hwnd, message, wparam, lparam)

    def _keyboard_proc(self, code, wparam, lparam):
        if code >= 0 and self._active_shortcut and self._active_shortcut.caps_lock:
            try:
                if ctypes.c_uint32.from_address(lparam).value == VK_CAPITAL:
                    event = int(wparam)
                    if event in (WM_KEYDOWN, WM_SYSKEYDOWN):
                        if not self._caps_is_down:
                            self._caps_is_down = True
                            if self._capture_mode:
                                self.events.put(("capture_key", "CapsLock"))
                            else:
                                self.events.put(("hotkey",))
                        return 1
                    if event in (WM_KEYUP, WM_SYSKEYUP):
                        self._caps_is_down = False
                        return 1
            except (ValueError, TypeError, ctypes.ArgumentError):
                return 1
        return user32.CallNextHookEx(self._hook, code, wparam, lparam)


# ---------------------------------------------------------------------------
# 트레이 앱과 설정 창
# ---------------------------------------------------------------------------

def _settings_path() -> Path:
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
    return base / "HangulSwitcher" / "settings.json"


def _load_shortcut() -> Shortcut:
    path = _settings_path()
    try:
        saved = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(saved, dict):
            return parse_shortcut("CapsLock")
        value = saved.get("shortcut", "CapsLock")
        return parse_shortcut(value) if isinstance(value, str) else parse_shortcut("CapsLock")
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return parse_shortcut("CapsLock")


def _save_shortcut(shortcut: Shortcut) -> None:
    path = _settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"shortcut": shortcut.text}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


class HangulSwitcherApp:
    def __init__(self, *, diagnostics=False):
        self.root = tk.Tk(useTk=False)
        self._ui_loaded = False
        self.icon_path = Path(__file__).with_name("hangul_switcher.ico")
        self.events = queue.SimpleQueue()
        self.closed = False
        self.busy = False
        self._conversion_token = 0
        self._conversion_timer = None
        self._conversion_deadline = 0.0
        self._conversion_worker = None
        self.copy_sequence = None
        self.target_window = None
        self.settings_window = None
        self.settings_close_button = None
        self._tray_unavailable = False
        self.settings_status = None
        self.shortcut_value = None
        self.capture_button = None
        self.capture_active = False
        self.capture_modifiers = set()
        self.pending_shortcut = None
        self.active_shortcut = _load_shortcut()
        self.suspended = False
        self._enabled_request_pending = False
        self.tray_popup = None
        self.tray_switch_canvas = None
        self.tray_switch_status = None
        self.tray_switch_x = 38 if not self.suspended else 14
        self._switch_animation_job = None

        self.host = NativeHost(self.events, self.active_shortcut, diagnostics=diagnostics)
        try:
            self.host.start()
        except Exception:
            self._destroy_root()
            raise
        self._poll_events()

    def _destroy_root(self) -> None:
        for job in self.root.tk.call("after", "info"):
            self.root.after_cancel(job)
        try:
            self.root.destroy()
        except tk.TclError:
            tk.Misc.destroy(self.root)

    def _ensure_ui(self) -> None:
        if not self._ui_loaded:
            self.root.loadtk()
            self.root.withdraw()
            self.root.title(APP_NAME)
            self.root.protocol("WM_DELETE_WINDOW", self.shutdown)
            _set_window_icon(self.root, self.icon_path, default=True)
            self._ui_loaded = True

    def _show_error(self, title: str, detail: str, **kwargs) -> None:
        self._ensure_ui()
        messagebox.showerror(title, detail, **kwargs)

    def run(self) -> None:
        # Tcl timers work before the first tray/settings window needs Tk.
        while not self.closed:
            self.root.tk.dooneevent(0)

    def _poll_events(self) -> None:
        if self.closed:
            return
        while True:
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            kind = event[0]
            if kind == "hotkey":
                self._start_conversion()
            elif kind == "conversion_result":
                token, sequence, converted, error = event[1:]
                if token == self._conversion_token:
                    if error:
                        self._cancel_conversion()
                        self._set_status(f"변환하지 못했습니다: {error}")
                    else:
                        self._paste_converted(converted, token, sequence)
            elif kind in ("tray_left", "tray_right"):
                self._show_tray_menu()
            elif kind == "capture_key":
                self._accept_capture_key(event[1])
            elif kind == "shortcut_result":
                self._shortcut_result(event[1], event[2], event[3])
            elif kind == "enabled_result":
                self._enabled_result(event[1], event[2], event[3])
            elif kind == "tray_error":
                if not self._tray_unavailable:
                    self._tray_unavailable = True
                    self.show_settings()
                if self.settings_close_button:
                    self.settings_close_button.configure(text="프로그램 종료")
                self._set_status(f"트레이 아이콘을 등록하지 못했습니다: {event[1]}\n"
                                 "이 창에서 설정할 수 있습니다. 닫으면 프로그램이 종료됩니다.")
            elif kind == "tray_ready":
                if self._tray_unavailable:
                    self._tray_unavailable = False
                    if self.settings_close_button:
                        self.settings_close_button.configure(text="닫기")
                    self._set_status(f"트레이 아이콘이 복구되었습니다. 현재 단축키: {self.active_shortcut.text}")
            elif kind == "startup_error":
                self._show_error("시작 오류", event[1])
        self.root.after(50, self._poll_events)

    def _cancel_conversion(self) -> None:
        self._conversion_token += 1
        if self._conversion_timer is not None:
            self.root.after_cancel(self._conversion_timer)
            self._conversion_timer = None
        self.busy = False

    def _conversion_valid(self) -> bool:
        return (not self.closed and not self.suspended and self.busy
                and user32.GetForegroundWindow() == self.target_window)

    def _schedule_conversion(self, callback) -> None:
        self._conversion_timer = self.root.after(15, callback)

    def _start_conversion(self) -> None:
        if self.closed or self.suspended or self.busy:
            return
        if self._conversion_worker and self._conversion_worker.is_alive():
            return
        self.target_window = user32.GetForegroundWindow()
        if not self.target_window:
            return
        self._conversion_token += 1
        self.busy = True
        self._conversion_deadline = time.monotonic() + 1.0
        self._begin_copy()

    def _begin_copy(self) -> None:
        self._conversion_timer = None
        if not self._conversion_valid() or time.monotonic() >= self._conversion_deadline:
            self._cancel_conversion()
            return
        if _modifiers_down():
            self._schedule_conversion(self._begin_copy)
            return
        self.copy_sequence = user32.GetClipboardSequenceNumber()
        _press_ctrl_key(ord("C"))
        self._conversion_deadline = time.monotonic() + 0.75
        self._schedule_conversion(self._finish_copy_and_paste)

    def _finish_copy_and_paste(self) -> None:
        self._conversion_timer = None
        if not self._conversion_valid() or time.monotonic() >= self._conversion_deadline:
            self._cancel_conversion()
            return
        sequence = user32.GetClipboardSequenceNumber()
        if sequence == self.copy_sequence:
            self._schedule_conversion(self._finish_copy_and_paste)
            return
        selected = _read_clipboard_text(self.host.hwnd)
        if selected is None:
            self._schedule_conversion(self._finish_copy_and_paste)
            return
        if not selected or user32.GetClipboardSequenceNumber() != sequence:
            self._cancel_conversion()
            return
        token = self._conversion_token
        if len(selected) < 32768:
            try:
                converted = convert_text(selected)
            except Exception:
                self._cancel_conversion()
                raise
            self._paste_converted(converted if converted != selected else None, token, sequence)
        else:
            self._conversion_worker = threading.Thread(
                target=self._convert_in_background, args=(selected, token, sequence),
                name="HangulSwitcherConvert", daemon=True,
            )
            self._conversion_worker.start()

    def _convert_in_background(self, selected: str, token: int, sequence: int) -> None:
        try:
            converted = convert_text(selected)
            result = ("conversion_result", token, sequence,
                      converted if converted != selected else None, None)
        except Exception as exc:
            result = ("conversion_result", token, sequence, None, str(exc))
        if not self.closed:
            self.events.put(result)

    def _paste_converted(self, converted: str | None, token: int, sequence: int) -> None:
        if token != self._conversion_token:
            return
        try:
            if not converted or not self._conversion_valid():
                return
            if user32.GetClipboardSequenceNumber() != sequence:
                return
            if _modifiers_down():
                return
            if not _write_clipboard_text(self.host.hwnd, converted):
                self._set_status("클립보드에 접근하지 못해 변환하지 못했습니다.")
                return
            _press_ctrl_key(ord("V"))
        finally:
            self.busy = False

    def show_settings(self) -> None:
        self._ensure_ui()
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.deiconify()
            self.settings_window.lift()
            self.settings_window.focus_force()
            return

        window = tk.Toplevel(self.root)
        self.settings_window = window
        _set_window_icon(window, self.icon_path)
        window.title(f"{APP_NAME} 설정")
        window.resizable(False, False)
        window.protocol("WM_DELETE_WINDOW", self._hide_settings)
        window.bind("<KeyPress>", self._capture_keypress, add="+")
        window.bind("<KeyRelease>", self._capture_keyrelease, add="+")

        frame = tk.Frame(window, padx=16, pady=14)
        frame.pack(fill="both", expand=True)
        tk.Label(frame, text="변환 단축키").grid(row=0, column=0, sticky="w")
        self.shortcut_value = tk.StringVar(value=self.active_shortcut.text)
        display = tk.Label(
            frame, textvariable=self.shortcut_value, width=22, anchor="w",
            relief="sunken", padx=7, pady=5, takefocus=True,
        )
        display.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(5, 8))

        tk.Label(
            frame,
            text="‘키 눌러 지정’을 누른 뒤 원하는 키를 누르세요. 예: Ctrl+T",
            fg="#555555",
        ).grid(row=2, column=0, columnspan=3, sticky="w")

        self.settings_status = tk.StringVar(
            value="조합은 수정 키 하나와 일반 키 하나까지 사용할 수 있습니다."
        )
        tk.Label(
            frame, textvariable=self.settings_status, fg="#555555",
            wraplength=360, justify="left",
        ).grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 10))

        self.capture_button = tk.Button(
            frame, text="키 눌러 지정", command=self._toggle_capture
        )
        self.capture_button.grid(row=4, column=0, sticky="e", padx=(0, 6))
        tk.Button(frame, text="초기화", command=self._reset_shortcut).grid(
            row=4, column=1, padx=6
        )
        self.settings_close_button = tk.Button(frame, text="닫기", command=self._hide_settings)
        self.settings_close_button.grid(row=4, column=2, sticky="w", padx=(6, 0))
        display.focus_set()

    def _toggle_capture(self) -> None:
        if self.capture_active:
            self._cancel_capture()
            return
        self.capture_active = True
        self.capture_modifiers.clear()
        if self.capture_button:
            self.capture_button.configure(text="취소")
        self._set_status("지정할 키 조합을 누르세요. 예: Ctrl+T")
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.focus_force()
        self.host.set_capture_mode(True)

    def _cancel_capture(self) -> None:
        if not self.capture_active:
            return
        self.capture_active = False
        self.capture_modifiers.clear()
        if self.capture_button:
            try:
                self.capture_button.configure(text="키 눌러 지정")
            except tk.TclError:
                pass
        self.host.set_capture_mode(False)

    def _hide_settings(self) -> None:
        if self._tray_unavailable:
            self.shutdown()
            return
        self._cancel_capture()
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.withdraw()

    def _reset_shortcut(self) -> None:
        self._cancel_capture()
        self._request_shortcut(parse_shortcut("CapsLock"))

    def _capture_keypress(self, event):
        if not self.capture_active:
            return None
        keycode = int(event.keycode)
        modifier = _capture_modifier_name(keycode)
        if modifier:
            self.capture_modifiers.add(modifier)
            if len(self.capture_modifiers) > 1:
                self._set_status("최대 두 키 조합입니다. 조합 키 하나와 일반 키 하나를 누르세요.")
            return "break"

        if 0x41 <= keycode <= 0x5A:
            key_name = chr(keycode)
        elif 0x30 <= keycode <= 0x39:
            key_name = chr(keycode)
        elif 0x70 <= keycode <= 0x87:
            key_name = f"F{keycode - 0x70 + 1}"
        else:
            key_name = KEY_LABELS.get(keycode)
        if not key_name:
            self._set_status("이 키는 단축키로 지정할 수 없습니다. 다른 키를 눌러 주세요.")
            return "break"

        self._accept_capture_key(key_name)
        return "break"

    def _capture_keyrelease(self, event):
        if not self.capture_active:
            return None
        keycode = int(event.keycode)
        modifier = _capture_modifier_name(keycode)
        if modifier:
            self.capture_modifiers.discard(modifier)
        return "break"

    def _accept_capture_key(self, key_name: str) -> None:
        if not self.capture_active:
            return
        if len(self.capture_modifiers) > 1:
            self.capture_modifiers.clear()
            self._set_status("조합 키 하나와 일반 키 하나만 사용할 수 있습니다. 다시 눌러 주세요.")
            return
        modifier_name = next(iter(self.capture_modifiers), "")
        raw = f"{modifier_name}+{key_name}" if modifier_name else key_name
        self._request_captured_shortcut(raw)

    def _request_captured_shortcut(self, raw: str) -> None:
        try:
            shortcut = parse_shortcut(raw)
        except ValueError as exc:
            self._set_status(str(exc))
            self.capture_modifiers.clear()
            return
        self._cancel_capture()
        self._request_shortcut(shortcut)

    def _request_shortcut(self, shortcut: Shortcut) -> None:
        self.pending_shortcut = shortcut
        if self.shortcut_value is not None:
            self.shortcut_value.set(shortcut.text)
        self._set_status(f"{shortcut.text} 단축키를 등록하는 중입니다...")
        self.host.set_shortcut(shortcut)

    def _shortcut_result(self, success: bool, shortcut: Shortcut, error: str | None) -> None:
        if success:
            self.active_shortcut = shortcut
            if self.shortcut_value is not None:
                self.shortcut_value.set(shortcut.text)
            try:
                _save_shortcut(shortcut)
            except OSError as exc:
                self._set_status(f"단축키는 적용됐지만 설정 저장에 실패했습니다: {exc}")
            else:
                self._set_status(f"현재 단축키: {shortcut.text}")
        else:
            detail = error or "Windows에서 단축키를 등록하지 못했습니다."
            if self.shortcut_value is not None:
                self.shortcut_value.set(self.active_shortcut.text)
            self._set_status(f"등록 실패: {detail}")
            if self.settings_window and self.settings_window.winfo_exists():
                self._show_error(
                    "단축키 등록 실패",
                    "이 단축키는 다른 프로그램이 사용 중이거나 Windows에서 사용할 수 없습니다.\n\n"
                    + detail,
                    parent=self.settings_window,
                )
            else:
                self._show_error("단축키 등록 실패", detail)

        if self.pending_shortcut is shortcut:
            self.pending_shortcut = None

    def _toggle_suspended(self) -> None:
        if self._enabled_request_pending:
            return
        enabled = self.suspended
        if not enabled:
            self._cancel_conversion()
        self._enabled_request_pending = True
        self._set_status(
            "다시 시작하는 중..." if enabled else "일시 중단하는 중..."
        )
        if self.tray_switch_status is not None:
            self.tray_switch_status.configure(
                text="다시 시작 중..." if enabled else "일시 중단 중...",
                fg="#555555",
            )
        self._animate_tray_switch(enabled)
        self.host.set_enabled(enabled)

    def _enabled_result(
        self, enabled: bool, success: bool, error: str | None
    ) -> None:
        if success:
            self.suspended = not enabled
            if not enabled:
                self._cancel_conversion()
            self._set_status(
                "변환 기능이 다시 시작되었습니다."
                if enabled else "일시 중단되었습니다. 트레이 메뉴에서 다시 시작할 수 있습니다."
            )
            self._enabled_request_pending = False
            self._update_tray_switch_status()
            self._animate_tray_switch(enabled)
            return

        detail = error or "Windows에서 단축키를 등록하지 못했습니다."
        action = "다시 시작" if enabled else "일시 중단"
        self._enabled_request_pending = False
        self._set_status(f"{action}하지 못했습니다: {detail}")
        self._update_tray_switch_status()
        self._animate_tray_switch(not self.suspended)
        self._show_error(
            f"{action} 실패",
            f"{action} 요청을 처리하지 못했습니다.\n\n{detail}",
        )

    def _set_status(self, text: str) -> None:
        if self.settings_status is not None:
            try:
                self.settings_status.set(text)
            except tk.TclError:
                pass

    def _show_tray_menu(self) -> None:
        self._ensure_ui()
        if self.tray_popup and self.tray_popup.winfo_exists():
            self.tray_popup.lift()
            self.tray_popup.focus_force()
            return

        popup = tk.Toplevel(self.root)
        self.tray_popup = popup
        popup.overrideredirect(True)
        popup.attributes("-topmost", True)
        popup.configure(bg="#D1D5DB")
        popup.bind("<Escape>", lambda _event: self._close_tray_popup())
        popup.bind("<FocusOut>", self._tray_popup_focus_out, add="+")

        panel = tk.Frame(popup, bg="#FFFFFF", bd=1, relief="solid")
        panel.pack(padx=1, pady=1)
        tk.Label(
            panel, text=APP_NAME, bg="#FFFFFF", fg="#202124",
            font=("맑은 고딕", 10, "bold"), anchor="w",
        ).pack(fill="x", padx=13, pady=(11, 7))

        toggle_row = tk.Frame(panel, bg="#FFFFFF")
        toggle_row.pack(fill="x", padx=13, pady=(2, 10))
        self.tray_switch_status = tk.Label(
            toggle_row, text="", bg="#FFFFFF", fg="#202124",
            font=("맑은 고딕", 9), anchor="w",
        )
        self.tray_switch_status.pack(side="left", fill="x", expand=True)
        self.tray_switch_canvas = tk.Canvas(
            toggle_row, width=52, height=32, bg="#FFFFFF",
            highlightthickness=0, cursor="hand2",
        )
        self.tray_switch_canvas.pack(side="right")
        self.tray_switch_canvas.bind("<Button-1>", lambda _event: self._toggle_suspended())
        self._update_tray_switch_status()
        self._draw_tray_switch()

        separator = tk.Frame(panel, height=1, bg="#E5E7EB")
        separator.pack(fill="x", padx=9, pady=(0, 7))
        tk.Button(
            panel, text="단축키 설정", anchor="w", relief="flat", bg="#FFFFFF",
            activebackground="#F3F4F6", command=self._open_settings_from_tray,
        ).pack(fill="x", padx=6, pady=1, ipady=4)
        tk.Button(
            panel, text="프로그램 종료", anchor="w", relief="flat", bg="#FFFFFF",
            activebackground="#F3F4F6", command=self._exit_from_tray,
        ).pack(fill="x", padx=6, pady=(1, 6), ipady=4)

        popup.update_idletasks()
        x = self.root.winfo_pointerx()
        y = self.root.winfo_pointery()
        x = min(x, popup.winfo_screenwidth() - popup.winfo_reqwidth() - 4)
        y = min(y, popup.winfo_screenheight() - popup.winfo_reqheight() - 4)
        popup.geometry(f"+{max(0, x)}+{max(0, y)}")
        popup.after_idle(popup.focus_force)

    def _open_settings_from_tray(self) -> None:
        self._close_tray_popup()
        self.show_settings()

    def _exit_from_tray(self) -> None:
        self._close_tray_popup()
        self.shutdown()

    def _cancel_switch_animation(self) -> None:
        if self._switch_animation_job is not None:
            try:
                self.root.after_cancel(self._switch_animation_job)
            except tk.TclError:
                pass
            self._switch_animation_job = None

    def _close_tray_popup(self) -> None:
        self._cancel_switch_animation()
        popup = self.tray_popup
        self.tray_popup = None
        self.tray_switch_canvas = None
        self.tray_switch_status = None
        if popup and popup.winfo_exists():
            popup.destroy()

    def _tray_popup_focus_out(self, _event) -> None:
        popup = self.tray_popup
        if not popup:
            return

        def close_if_outside():
            if not self.tray_popup or not self.tray_popup.winfo_exists():
                return
            focused = self.tray_popup.focus_get()
            if focused is None or focused.winfo_toplevel() is not self.tray_popup:
                self._close_tray_popup()

        popup.after_idle(close_if_outside)

    def _update_tray_switch_status(self) -> None:
        if self.tray_switch_status is None:
            return
        if self._enabled_request_pending:
            self.tray_switch_status.configure(
                text="다시 시작 중..." if self.suspended else "일시 중단 중...",
                fg="#555555",
            )
            return
        enabled = not self.suspended
        self.tray_switch_status.configure(
            text="변환 켜짐" if enabled else "변환 일시 중단",
            fg="#228B45" if enabled else "#6B7280",
        )

    def _draw_tray_switch(self, knob_x: float | None = None, enabled: bool | None = None) -> None:
        canvas = self.tray_switch_canvas
        if canvas is None:
            return
        if enabled is None:
            enabled = not self.suspended
        if knob_x is None:
            knob_x = 38 if enabled else 14
        self.tray_switch_x = knob_x
        canvas.delete("all")
        track_color = "#34C759" if enabled else "#A0A2A4"
        canvas.create_oval(2, 4, 26, 28, fill=track_color, outline=track_color)
        canvas.create_rectangle(14, 4, 38, 28, fill=track_color, outline=track_color)
        canvas.create_oval(26, 4, 50, 28, fill=track_color, outline=track_color)
        canvas.create_oval(
            knob_x - 9, 7, knob_x + 9, 25,
            fill="#FFFFFF", outline="#E5E7EB", width=1,
        )

    def _animate_tray_switch(self, enabled: bool) -> None:
        self._cancel_switch_animation()
        if self.tray_switch_canvas is None:
            return

        start = self.tray_switch_x
        target = 38 if enabled else 14
        frames = 6

        def draw_frame(frame: int) -> None:
            if self.tray_switch_canvas is None:
                return
            position = start + (target - start) * frame / frames
            self._draw_tray_switch(position, enabled)
            if frame < frames:
                self._switch_animation_job = self.root.after(
                    18, lambda: draw_frame(frame + 1)
                )
            else:
                self._switch_animation_job = None

        draw_frame(1)

    def shutdown(self) -> None:
        if self.closed:
            return
        self.closed = True
        self._cancel_conversion()
        self.host.stop()
        self._destroy_root()


def main() -> None:
    try:
        app = HangulSwitcherApp(diagnostics="--self-test" in sys.argv)
    except Exception as exc:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, str(exc))
        root.destroy()
        return
    if "--self-test" in sys.argv:
        app.root.after(5000, app.shutdown)
    app.run()


if __name__ == "__main__":
    main()
