﻿param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
$taskProject = $PSScriptRoot
& $Python -c 'import tkinter, _tkinter; r=tkinter.Tk(); r.withdraw(); r.destroy()'
if ($LASTEXITCODE -ne 0) { throw 'Tkinter/Tcl/Tk runtime check failed.' }
& $Python -m PyInstaller --noconfirm --clean --onefile --windowed --noupx --optimize 1 `
    --name '넌 한영키를 누르지 못했다(beta)' `
    --icon (Join-Path $taskProject 'hangul_switcher.ico') `
    --add-data ((Join-Path $taskProject 'hangul_switcher.ico') + ';.') `
    --distpath (Join-Path $taskProject 'dist') `
    --workpath (Join-Path $taskProject '.build') `
    --specpath (Join-Path $taskProject '.build') `
    (Join-Path $taskProject 'hangul_switcher.pyw')
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }
Copy-Item -LiteralPath (Join-Path $taskProject 'README_hangul_switcher.txt') `
    -Destination (Join-Path $taskProject 'dist/README_hangul_switcher.txt')
